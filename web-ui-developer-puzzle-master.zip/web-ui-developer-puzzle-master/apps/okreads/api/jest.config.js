module.exports = {
  name: 'okreads-api',
  preset: '../../../jest.config.js',
  coverageDirectory: '../../../coverage/apps/okreads/api'
};
